1. What is a docker container? [2] 
A docker container is a package of code and its dependancies in order for it to be accessed in different computing environments.
2. What is the difference between a container and a virtual machine? [2] 
A container virtualized the operating system as oppose to the hardware.
3. What is the purpose of a Dockerfile? [2] 
A dockerfile iare all the commands needed to create an image
4. What is the purpose of a requirements.txt file? [2] 
To supply the dependancies 
5. What is the purpose of a docker-compose.yml file? [2] 
This allows us to configure and combine multiple containers at one time.
6. What is the difference between a docker image and docker container? [2] 
The docker image are the instructions to build a container
7. What command can be used to create an image from a Dockerfile? [2] 
$docker build
8. What command will start a docker container? [2] 
$docker start [OPTIONS] CONTAINER [CONTAINER...]
9. What command will stop a docker container? [2] 
$docker stop [OPTIONS] CONTAINER [CONTAINER...]
10. What command will remove a docker container?Image? [5] 
    1. container:$docker rm [OPTIONS] CONTAINER [CONTAINER...]
    2. mage:$docker rmi [OPTIONS] IMAGE [IMAGE...]
11. What command will list all running docker containers? all containers? [5] 
    1. All Running:$docker ps -a
    2. All:$docker ps
12. What command will list all docker images? 
$docker images
13. What command do you use to deploy docker containers using information in the docker-compose.yml file? [2] 
$docker-compose up
14. How can you specify in the docker-compose.yml file that you want docker containers to use the hosts network? [5] 
network_mode: host
15. How can you specify in the docker-compose.yml file where the Dockerfile for a particular container is found? [5]  
build: /