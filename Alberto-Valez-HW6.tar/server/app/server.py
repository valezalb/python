from flask import Flask

server = Flask(__name__)

@server.route('/')
def hello_world():
    return 'Hello, World!'

server.run(host='0.0.0.0', port=5000)